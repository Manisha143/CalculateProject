using CalculateProject;
using System;
using Xunit;

namespace CalculateTest.unit
{
    public class DatecalculatorTest
    {
        
        [Fact]
        public void TestAddOneDayToEndOfJanuary2016()
        {
            // Arrange
            string startDate = "31/01/2016";
            int daysToAdd = 1;
            string expectedDate = "01/02/2016";

            // Act
            string result = DateCalculator.AddDaysToDate(startDate, daysToAdd);

            // Assert
            Assert.Equal(expectedDate, result);
        }
        [Fact]
        public void TestAddOneDayToLeapYearEndOfFebruary2020()
        {
            // Arrange
            string startDate = "28/02/2020";
            int daysToAdd = 1;
            string expectedDate = "29/02/2020"; // Leap year case

            // Act
            string result = DateCalculator.AddDaysToDate(startDate, daysToAdd);

            // Assert
            Assert.Equal(expectedDate, result);
        }

        [Fact]
        public void TestAddOneDayToNonLeapYearEndOfFebruary2019()
        {
            // Arrange
            string startDate = "28/02/2019";
            int daysToAdd = 1;
            string expectedDate = "01/03/2019"; // Non-leap year case

            // Act
            string result = DateCalculator.AddDaysToDate(startDate, daysToAdd);

            // Assert
            Assert.Equal(expectedDate, result);
        }

        [Fact]
        public void TestAddOneDayToEndOfDecember2023()
        {
            // Arrange
            string startDate = "31/12/2023";
            int daysToAdd = 1;
            string expectedDate = "01/01/2024";

            // Act
            string result = DateCalculator.AddDaysToDate(startDate, daysToAdd);

            // Assert
            Assert.Equal(expectedDate, result);
        }

        [Fact]
        public void TestAddThirtyDaysToMidJuly2023()
        {
            // Arrange
            string startDate = "15/07/2023";
            int daysToAdd = 30;
            string expectedDate = "14/08/2023";

            // Act
            string result = DateCalculator.AddDaysToDate(startDate, daysToAdd);

            // Assert
            Assert.Equal(expectedDate, result);
        }
    }
}
