﻿using System;

namespace CalculateProject
{
    public class Program
    {
        static void Main(string[] args)
        {
            // Prompt the user to enter the date
            Console.WriteLine("Enter the date in dd/mm/yyyy format:");
            string startDate = Console.ReadLine();

            // Validate date input format
            if (!IsValidDateFormat(startDate))
            {
                Console.WriteLine("Invalid date format. Please enter the date in dd/mm/yyyy format.");
                return;
            }

            // Prompt the user to enter the number of days to add
            Console.WriteLine("Enter the number of days to add:");
            if (!int.TryParse(Console.ReadLine(), out int daysToAdd))
            {
                Console.WriteLine("Invalid number of days.");
                return;
            }

            // Calculate the new date
            string newDate = DateCalculator.AddDaysToDate(startDate, daysToAdd);

            // Display the result
            Console.WriteLine($"New Date: {newDate}");
        }
        // Method to validate date format
        private static bool IsValidDateFormat(string date)
        {
            var parts = date.Split('/');
            if (parts.Length != 3)
                return false;

            if (!int.TryParse(parts[0], out int day) || !int.TryParse(parts[1], out int month) || !int.TryParse(parts[2], out int year))
                return false;

            return day >= 1 && day <= 31 && month >= 1 && month <= 12 && year >= 1;
        }
    }

    public class DateCalculator
    {
        private static readonly int[] DaysInMonth = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

        public static string AddDaysToDate(string startDate, int daysToAdd)
        {
            var parts = startDate.Split('/');
            int day = int.Parse(parts[0]);
            int month = int.Parse(parts[1]);
            int year = int.Parse(parts[2]);

            // Check for leap year
            if (IsLeapYear(year))
            {
                DaysInMonth[1] = 29;
            }

            day += daysToAdd;

            while (day > DaysInMonth[month - 1])
            {
                day -= DaysInMonth[month - 1];
                month++;
                if (month > 12)
                {
                    month = 1;
                    year++;
                    // Recalculate for leap year
                    if (IsLeapYear(year))
                    {
                        DaysInMonth[1] = 29;
                    }
                    else
                    {
                        DaysInMonth[1] = 28;
                    }
                }
            }

            return $"{day:D2}/{month:D2}/{year}";
        }

        private static bool IsLeapYear(int year)
        {
            if (year % 4 != 0)
                return false;
            if (year % 100 != 0)
                return true;
            if (year % 400 != 0)
                return false;
            return true;
        }
    }

}

